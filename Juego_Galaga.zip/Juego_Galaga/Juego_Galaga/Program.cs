﻿
using var game = new Juego_Galaga.Game1();
game.Run();
